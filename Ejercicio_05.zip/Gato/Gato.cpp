#include "Gato.h"
#include<iostream>
using namespace std;
Gato::Gato(int edadInicial,int pesoInicial)
{
    suEdad=edadInicial;
    cout<<"Se ha creado un objeto Gato de edad "<<edadInicial<<endl;
    suPeso=pesoInicial;
    cout<<"Con un peso de "<<pesoInicial<<" kilogramos"<<endl;
}

Gato::~Gato()
{
    cout<<"El objeto Gato se destruira en 3,2,1 ..... ya fue"<<endl;
}
int Gato::ObtenerEdad() const
{
    return suEdad;
}
void Gato::AsignarEdad(int edad)
{
    suEdad=edad;
}
int Gato::ObtenerPeso() const
{
    return suPeso;
}
void Gato::AsignarPeso(int peso)
{
    suPeso=peso;
}
void Gato::Maullar()
{
    cout<<"Miauuuuuuu"<<endl;
}
