#include <iostream>
#include "Gato.h"
using namespace std;

int main(void)
{
    Gato Pelusa(5,8);
    Pelusa.Maullar();
    cout<<"Pelusa es un gato que tiene "<<Pelusa.ObtenerEdad()<<" anios de edad"<<endl;
    cout<<"Y que pesa "<<Pelusa.ObtenerPeso()<<" kilogramos"<<endl;
    Pelusa.Maullar();
    Pelusa.AsignarEdad(7);
    Pelusa.AsignarPeso(10);
    cout<<"Ahora Pelusa tiene "<<Pelusa.ObtenerEdad()<<" anios de edad"<<endl;
    cout<<"Y que pesa "<<Pelusa.ObtenerPeso()<<" kilogramos"<<endl;
    return 0;
}
