#ifndef GATO_H
#define GATO_H

class Gato
{
    public:
        Gato(int edadInicial,int pesoInicial);
        ~Gato();
        int ObtenerEdad() const;
        int ObtenerPeso() const;
        void AsignarEdad(int edad);
        void AsignarPeso(int peso);
        void Maullar();
    private:
        int suEdad;
        int suPeso;
};

#endif
