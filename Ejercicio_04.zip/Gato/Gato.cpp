#include "Gato.h"
#include<iostream>
using namespace std;

Gato::Gato(int edadInicial)
{
    suEdad=edadInicial;
    cout<<"Se ha creado un objeto Gato de Edad"<<edadInicial<<endl;
}
Gato::~Gato()
{
    cout<<"El objeto Gato se destruira en 3,2,1 ...... ya fue ....."<<endl;
}
void Gato::AsignarEdad(int edad)
{
    suEdad=edad;
}
int Gato::ObtenerEdad()
{
    return suEdad;
}
void Gato::Maullar()
{
    cout<<"Miaaaaauuuu"<<endl;
}
